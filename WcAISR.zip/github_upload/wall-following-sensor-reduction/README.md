# Importance-guided ultrasonic sensor reduction for wall-following robot navigation

Code and results for the conference paper *Importance-Guided Ultrasonic Sensor Reduction for Wall-Following Robot
Navigation: A Leakage-Aware Evaluation with Fault Analysis* (submitted to WcAISR-2027, Track 1).

We ask whether a Random Forest that sees only 10 of the 24 ultrasonic sensors of the UCI Wall-Following Robot
Navigation dataset still classifies the four motion commands as well as the full ring. The ranking is redone inside
every training set, and the blocked folds keep test readings apart in time from training readings.

## Contents

| Path | Content |
|---|---|
| `run_experiments.py` | All experiments: replication of the original split, 10 stratified random splits, 5 blocked contiguous folds (50-row gap), impurity and permutation rankings, feature-count curve (k = 2–24), random-subset baseline, selection stability, synthetic fault tests |
| `make_figures.py` | The three figures of the paper from `results/` |
| `notebooks/worldconference.ipynb` | The original exploratory notebook (single split, Google Colab) |
| `results/` | `all_runs.csv`, `summary_curve.csv`, `paired_contrasts_k10.csv`, `selected_sensors.csv`, `fault_tests.csv`, `run_manifest.json` (versions, data hash, settings) |
| `figures/` | Feature-count curves, sensor-selection ring, fault tests (600 dpi); see the mapping below |
| `data/` | Filled by `run_experiments.py` (raw data are not redistributed) |

### Figures in the paper

| Paper figure | Files |
|---|---|
| Fig. 1 (a), (b): macro-F1 versus number of sensors | `fig2a_feature_count_random.png`, `fig2b_feature_count_blocked.png` |
| Fig. 2: how often each sensor entered the top 10 | `fig1_sensor_ring_compact.png` |
| Fig. 3 (a), (b): single-sensor outage, random dropout | `fig3a_single_outage.png`, `fig3b_random_dropout.png` |

`fig1_sensor_ring.png`, `fig2_feature_count.png` and `fig3_faults.png` are combined versions of the same plots.

## Running

```bash
pip install -r requirements.txt
python run_experiments.py   # downloads the UCI data, ~6 min on a laptop CPU, writes results/
python make_figures.py      # writes figures/
```

Ranking, selection, imputation and training see only the training part of each split. The faults are synthetic
(readings set missing), so they test offline classification, not navigation safety on a real robot.

## Main results

| Protocol | All 24 sensors | Top-10 (impurity) | Random 10 |
|---|---|---|---|
| 10 stratified random splits, accuracy | 99.29 ± 0.20 % | 99.44 ± 0.20 % | 95.35 ± 0.46 % |
| 5 blocked contiguous folds, accuracy | 98.64 ± 0.85 % | 98.64 ± 0.78 % | 89.29 ± 3.44 % |

US14, US15 and US17–US20 entered the top 10 in all 15 training sets. Losing US15 alone cut both the 24-sensor and
the 10-sensor model to 84–85 % accuracy, so the 14 extra channels gave no backup.

The numbers above come from Python 3.11.9, scikit-learn 1.9.1, NumPy 2.4.6, pandas
3.0.6 and SciPy 1.17.1. Single-split results shift with the library version: on the same split the
original Colab notebook gave 99.36 % for both sensor sets.

## Data

Freire, A., Veloso, M., & Barreto, G. (2009). Wall-Following Robot Navigation Data. UCI Machine Learning Repository.
https://doi.org/10.24432/C57C8W (CC BY 4.0).

## License

MIT (see `LICENSE`).
