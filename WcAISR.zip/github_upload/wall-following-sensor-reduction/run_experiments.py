"""Sensor-importance-guided feature reduction for wall-following robot navigation (UCI dataset 194).

Extends worldconference.ipynb with:
  E1 replication of the notebook (stratified 80:20 split, seed 42, RF 100 trees, balanced weights)
  E2 repeated stratified random splits (10 split seeds); top-10 selection refitted inside each training set;
     full-24 vs importance top-10 vs random-10 subsets; McNemar test on the notebook split
  E3 blocked (contiguous) 5-fold evaluation with a 50-row gap on each side of the test block
  E4 feature-count curve k = 2..24 for impurity and permutation rankings (both protocols)
  E5 selection stability (top-10 frequency, mean pairwise Jaccard)
  E6 synthetic sensor faults at test time: independent dropout and single-sensor outage
All selection uses training data only. Outputs: results/*.csv, results/*.json, figures/*.png
Run:  python run_experiments.py
"""
import hashlib
import io
import itertools
import json
import platform
import sys
import time
import urllib.request
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
import sklearn
from scipy.stats import binomtest
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.metrics import accuracy_score, balanced_accuracy_score, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parent
DATA, RES = ROOT / "data", ROOT / "results"
DATA.mkdir(exist_ok=True); RES.mkdir(exist_ok=True)
URL = "https://archive.ics.uci.edu/static/public/194/wall+following+robot+navigation+data.zip"
CLASSES = ["Move-Forward", "Sharp-Right-Turn", "Slight-Left-Turn", "Slight-Right-Turn"]
KS = [2, 4, 6, 8, 10, 12, 16, 20, 24]
N_RANDOM = 20          # random subsets per split for the random-10 baseline
SPLIT_SEEDS = list(range(10))
GAP = 50               # rows (~5.6 s at 9 Hz) removed on each side of a blocked test fold
T0 = time.time()


def get_dataset():
    path = DATA / "sensor_readings_24.data"
    if not path.exists():
        blob = urllib.request.urlopen(URL, timeout=120).read()
        with zipfile.ZipFile(io.BytesIO(blob)) as z:
            names = [n for n in z.namelist() if n.endswith("sensor_readings_24.data")]
            if names:
                path.write_bytes(z.read(names[0]))
            else:
                for n in z.namelist():
                    if n.lower().endswith(".zip"):
                        with zipfile.ZipFile(io.BytesIO(z.read(n))) as zi:
                            m = [k for k in zi.namelist() if k.endswith("sensor_readings_24.data")]
                            if m:
                                path.write_bytes(zi.read(m[0])); break
    df = pd.read_csv(path, header=None)
    assert df.shape == (5456, 25), df.shape
    X = df.iloc[:, :24].to_numpy(float)
    y = df.iloc[:, 24].astype(str).str.strip().to_numpy()
    return X, y, path


class Preprocess:
    """As in the notebook: per-sensor median imputation + missing-value indicator for every sensor."""
    def fit(self, X):
        self.med = np.nanmedian(X, axis=0); return self

    def transform(self, X):
        m = np.isnan(X)
        return np.hstack([np.where(m, self.med, X), m.astype(float)])


def rf(seed=42):
    return RandomForestClassifier(n_estimators=100, class_weight="balanced", random_state=seed, n_jobs=-1)


def fit_eval(Xtr, ytr, Xte, yte, cols, seed=42, return_model=False):
    pp = Preprocess().fit(Xtr[:, cols])
    m = rf(seed).fit(pp.transform(Xtr[:, cols]), ytr)
    pred = m.predict(pp.transform(Xte[:, cols]))
    out = dict(acc=accuracy_score(yte, pred), bacc=balanced_accuracy_score(yte, pred),
               mf1=f1_score(yte, pred, average="macro"))
    return (out, pred, m, pp) if return_model else (out, pred)


def rankings(Xtr, ytr, seed=42):
    """Impurity ranking from the full model on the training set; permutation ranking on an inner
    stratified 25 % validation part of the training set (model refitted on the inner 75 %)."""
    pp = Preprocess().fit(Xtr)
    m = rf(seed).fit(pp.transform(Xtr), ytr)
    imp = m.feature_importances_[:24]
    a, b, ya, yb = train_test_split(Xtr, ytr, test_size=0.25, random_state=seed, stratify=ytr)
    pp2 = Preprocess().fit(a)
    m2 = rf(seed).fit(pp2.transform(a), ya)
    # permute raw sensor columns, re-transform, so imputation masks stay consistent
    base = accuracy_score(yb, m2.predict(pp2.transform(b)))
    rng = np.random.default_rng(seed); perm = np.zeros(24)
    for j in range(24):
        drops = []
        for _ in range(5):
            bb = b.copy(); bb[:, j] = rng.permutation(bb[:, j])
            drops.append(base - accuracy_score(yb, m2.predict(pp2.transform(bb))))
        perm[j] = np.mean(drops)
    return np.argsort(imp)[::-1], np.argsort(perm)[::-1], imp, perm


def blocked_folds(n, k=5, gap=GAP):
    edges = np.linspace(0, n, k + 1).astype(int)
    for f in range(k):
        te = np.arange(edges[f], edges[f + 1])
        lo, hi = max(0, edges[f] - gap), min(n, edges[f + 1] + gap)
        tr = np.r_[np.arange(0, lo), np.arange(hi, n)]
        yield f, tr, te


X, y, path = get_dataset()
sha = hashlib.sha256(path.read_bytes()).hexdigest()
counts = pd.Series(y).value_counts()
print("data", X.shape, "sha256", sha[:16], counts.to_dict(), "NaN:", int(np.isnan(X).sum()))

# ---------------------------------------------------------------- E1 replication
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
full, pred_full, m_full, pp_full = fit_eval(Xtr, ytr, Xte, yte, list(range(24)), return_model=True)
top10_nb = list(np.argsort(m_full.feature_importances_[:24])[-10:])
top10, pred_top = fit_eval(Xtr, ytr, Xte, yte, top10_nb)
cm_full = confusion_matrix(yte, pred_full, labels=CLASSES); cm_top = confusion_matrix(yte, pred_top, labels=CLASSES)
cf, ct = pred_full == yte, pred_top == yte
b01, b10 = int((cf & ~ct).sum()), int((~cf & ct).sum())
mcnemar_p = binomtest(b01, b01 + b10, 0.5).pvalue if b01 + b10 else 1.0
E1 = dict(full=full, top10=top10, top10_sensors=[int(i) + 1 for i in top10_nb[::-1]],
          cm_full=cm_full.tolist(), cm_top10=cm_top.tolist(), classes=CLASSES,
          discordant_full_only_correct=b01, discordant_top10_only_correct=b10, mcnemar_exact_p=mcnemar_p,
          n_test=len(yte), n_train=len(ytr))
print("E1", json.dumps({k: E1[k] for k in ("full", "top10", "top10_sensors", "mcnemar_exact_p")}))

# ---------------------------------------------------------------- E2/E4/E5 random-split protocol
rows, sel_rows = [], []
for s in SPLIT_SEEDS:
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=s, stratify=y)
    r_imp, r_perm, imp, perm = rankings(Xtr, ytr, seed=s)
    sel_rows.append(dict(protocol="random", unit=s, imp_top10=sorted(int(i) + 1 for i in r_imp[:10]),
                         perm_top10=sorted(int(i) + 1 for i in r_perm[:10])))
    for k in KS:
        for name, r in (("impurity", r_imp), ("permutation", r_perm)):
            if k == 24 and name == "permutation":
                continue
            met, _ = fit_eval(Xtr, ytr, Xte, yte, list(r[:k]), seed=s)
            rows.append(dict(protocol="random", unit=s, k=k, ranking=name if k < 24 else "all", **met))
    rng = np.random.default_rng(1000 + s)
    for j in range(N_RANDOM):
        cols = list(rng.choice(24, 10, replace=False))
        met, _ = fit_eval(Xtr, ytr, Xte, yte, cols, seed=s)
        rows.append(dict(protocol="random", unit=s, k=10, ranking=f"random_{j}", **met))
    print(f"  random split {s} done {time.time() - T0:.0f}s")

# ---------------------------------------------------------------- E3/E4/E5 blocked protocol
fold_info = []
for f, tr, te in blocked_folds(len(y)):
    Xtr, ytr, Xte, yte = X[tr], y[tr], X[te], y[te]
    fold_info.append(dict(fold=f, n_train=len(tr), n_test=len(te),
                          test_classes=pd.Series(yte).value_counts().to_dict()))
    r_imp, r_perm, imp, perm = rankings(Xtr, ytr, seed=42)
    sel_rows.append(dict(protocol="blocked", unit=f, imp_top10=sorted(int(i) + 1 for i in r_imp[:10]),
                         perm_top10=sorted(int(i) + 1 for i in r_perm[:10])))
    for k in KS:
        for name, r in (("impurity", r_imp), ("permutation", r_perm)):
            if k == 24 and name == "permutation":
                continue
            met, _ = fit_eval(Xtr, ytr, Xte, yte, list(r[:k]))
            rows.append(dict(protocol="blocked", unit=f, k=k, ranking=name if k < 24 else "all", **met))
    rng = np.random.default_rng(2000 + f)
    for j in range(N_RANDOM):
        cols = list(rng.choice(24, 10, replace=False))
        met, _ = fit_eval(Xtr, ytr, Xte, yte, cols)
        rows.append(dict(protocol="blocked", unit=f, k=10, ranking=f"random_{j}", **met))
    print(f"  blocked fold {f} done {time.time() - T0:.0f}s")

R = pd.DataFrame(rows); R.to_csv(RES / "all_runs.csv", index=False)
S = pd.DataFrame(sel_rows); S.to_csv(RES / "selected_sensors.csv", index=False)


def summarise(df):
    g = df.groupby(["protocol", "k", "ranking"])[["acc", "bacc", "mf1"]]
    out = g.agg(["mean", "std", "count"])
    out.columns = [f"{a}_{b}" for a, b in out.columns]
    return out.reset_index()


Rn = R.copy(); Rn.loc[Rn.ranking.str.startswith("random_"), "ranking"] = "random10"
# random10: average the 20 subsets within each unit first, so units are the replicates
rnd = Rn[Rn.ranking == "random10"].groupby(["protocol", "unit", "k", "ranking"])[["acc", "bacc", "mf1"]].mean().reset_index()
SUM = summarise(pd.concat([Rn[Rn.ranking != "random10"], rnd]))
SUM.to_csv(RES / "summary_curve.csv", index=False)

# paired contrasts at k = 10 (per unit), t-based 95 % CI
def paired(protocol, a, b, metric="mf1"):
    pa = Rn[(Rn.protocol == protocol) & (Rn.k == (24 if a == "all" else 10)) & (Rn.ranking == a)].set_index("unit")[metric]
    pb = (rnd if b == "random10" else Rn)
    pb = pb[(pb.protocol == protocol) & (pb.k == (24 if b == "all" else 10)) & (pb.ranking == b)].set_index("unit")[metric]
    d = (pa - pb).dropna(); n = len(d)
    se = d.std(ddof=1) / np.sqrt(n); tq = scipy.stats.t.ppf(0.975, n - 1)
    return dict(protocol=protocol, contrast=f"{a} - {b}", metric=metric, n=n, mean=d.mean(),
                lo=d.mean() - tq * se, hi=d.mean() + tq * se, min=d.min(), max=d.max())

import scipy.stats  # noqa: E402
C = []
for p in ("random", "blocked"):
    for a, b in (("impurity", "all"), ("permutation", "all"), ("impurity", "random10"), ("impurity", "permutation")):
        for met in ("acc", "mf1"):
            C.append(paired(p, a, b, met))
C = pd.DataFrame(C); C.to_csv(RES / "paired_contrasts_k10.csv", index=False)

# stability
def jacc(sets):
    pairs = list(itertools.combinations(sets, 2))
    return float(np.mean([len(set(a) & set(b)) / len(set(a) | set(b)) for a, b in pairs]))
STAB = {}
for p in ("random", "blocked"):
    sub = S[S.protocol == p]
    for col in ("imp_top10", "perm_top10"):
        freq = pd.Series([s for lst in sub[col] for s in lst]).value_counts().sort_index()
        STAB[f"{p}_{col}"] = dict(mean_jaccard=jacc(list(sub[col])), n_sets=len(sub),
                                  frequency={int(k): int(v) for k, v in freq.items()})

# ---------------------------------------------------------------- E6 synthetic faults (notebook split)
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
models = {}
for name, cols in (("all24", list(range(24))), ("top10", top10_nb)):
    pp = Preprocess().fit(Xtr[:, cols]); m = rf().fit(pp.transform(Xtr[:, cols]), ytr)
    models[name] = (cols, pp, m)
F = []
for prate in (0.0, 0.05, 0.10, 0.20, 0.30):
    for rep in range(10):
        rng = np.random.default_rng(rep)
        mask = rng.random(Xte.shape) < prate
        Xf = Xte.copy(); Xf[mask] = np.nan
        for name, (cols, pp, m) in models.items():
            pred = m.predict(pp.transform(Xf[:, cols]))
            F.append(dict(fault="dropout", level=prate, rep=rep, model=name, acc=accuracy_score(yte, pred),
                          mf1=f1_score(yte, pred, average="macro")))
for j in range(24):                          # one sensor fails completely (reads missing)
    Xf = Xte.copy(); Xf[:, j] = np.nan
    for name, (cols, pp, m) in models.items():
        pred = m.predict(pp.transform(Xf[:, cols]))
        F.append(dict(fault="single_outage", level=j + 1, rep=0, model=name, acc=accuracy_score(yte, pred),
                      mf1=f1_score(yte, pred, average="macro"), sensor_used=j in cols))
F = pd.DataFrame(F); F.to_csv(RES / "fault_tests.csv", index=False)

manifest = dict(data_url=URL, data_sha256=sha, n=len(y), class_counts=counts.to_dict(),
                python=platform.python_version(), sklearn=sklearn.__version__, numpy=np.__version__,
                pandas=pd.__version__, scipy=scipy.__version__, split_seeds=SPLIT_SEEDS, ks=KS,
                n_random_subsets=N_RANDOM, blocked_gap_rows=GAP, blocked_folds=fold_info, E1=E1,
                stability=STAB, runtime_s=round(time.time() - T0, 1))
(RES / "run_manifest.json").write_text(json.dumps(manifest, indent=1, default=float), encoding="utf-8")
print("done", round(time.time() - T0, 1), "s")
