# Data

The raw file `sensor_readings_24.data` is downloaded automatically by `run_experiments.py` from the UCI Machine Learning Repository (dataset 194, doi:10.24432/C57C8W, CC BY 4.0) and is not redistributed here.

SHA-256 of the file used for the reported results: `6e9728dedef8b35e31ba0be11aea85aa53bd248ab33652777df81b95a4cc8c00`
