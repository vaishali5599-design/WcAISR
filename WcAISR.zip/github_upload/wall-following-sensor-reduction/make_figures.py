"""IEEE single-column figures (3.45 in wide) from results/*.csv. Run after run_experiments.py."""
import ast
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parent
RES, FIG = ROOT / "results", ROOT / "figures"; FIG.mkdir(exist_ok=True)
C1, C2, C3, GREY, INK, INK2, GRID = "#2a78d6", "#eb6834", "#1baf7a", "#8c8b87", "#0b0b0b", "#52514e", "#dddcd8"
plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "DejaVu Serif"], "font.size": 8,
                     "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
                     "grid.linewidth": 0.5, "axes.axisbelow": True, "legend.frameon": False, "savefig.dpi": 600,
                     "savefig.bbox": "tight", "lines.linewidth": 1.4, "mathtext.fontset": "stix"})
W = 3.45
ANG = {k: ((180 + 15 * (k - 1) + 180) % 360) - 180 for k in range(1, 25)}   # UCI reference angles, US1 = 180°


def save(fig, name):
    fig.savefig(FIG / name); plt.close(fig); print("saved", name)


# ------------------------------------------------------------- Fig. 1 sensor ring and selection frequency
S = pd.read_csv(RES / "selected_sensors.csv")
sets = [ast.literal_eval(v) for v in S["imp_top10"]]
freq = {k: sum(k in s for s in sets) for k in range(1, 25)}
n = len(sets)
fig = plt.figure(figsize=(W, 2.75))
ax = fig.add_subplot(111, projection="polar")
ax.set_theta_zero_location("N"); ax.set_theta_direction(1)
ax.set_ylim(0, 1.32); ax.set_yticks([]); ax.set_xticks([]); ax.grid(False); ax.spines["polar"].set_visible(False)
ax.add_patch(plt.Circle((0, 0), 0.62, transform=ax.transData._b, fc="#f1f0ec", ec=INK2, lw=0.8, zorder=0))
cmap = LinearSegmentedColormap.from_list("blue", ["#ffffff", "#cfe0f6", "#7fb0ea", C1, "#174a8c"])
for k in range(1, 25):
    th = np.deg2rad(ANG[k] - 180)                      # display: US1 (front) at the top
    f = freq[k] / n
    ax.scatter(th, 1.0, s=150, c=[cmap(0.08 + 0.92 * f)], edgecolors=INK2, linewidths=0.7, zorder=3)
    ax.text(th, 1.0, str(k), ha="center", va="center", fontsize=6.3, color="white" if f > 0.6 else INK, zorder=4)
    if freq[k]:
        ax.text(th, 1.24, f"{freq[k]}", ha="center", va="center", fontsize=6, color=INK2)
ax.annotate("", xy=(0, 0.36), xytext=(0, 0.02), arrowprops=dict(arrowstyle="-|>", color=INK2, lw=0.9))
ax.text(0, 0.48, "front", ha="center", va="center", fontsize=6.5, color=INK2)
ax.text(np.pi, 0.25, "robot", ha="center", va="center", fontsize=7, color=INK2)
sm = plt.cm.ScalarMappable(cmap=cmap, norm=plt.Normalize(0, n)); sm.set_array([])
cb = fig.colorbar(sm, ax=ax, fraction=0.04, pad=0.08, ticks=[0, 5, 10, 15])
cb.set_label(f"times in impurity top-10 (of {n})", fontsize=7); cb.ax.tick_params(labelsize=6.5); cb.outline.set_linewidth(0.5)
save(fig, "fig1_sensor_ring.png")

# Compact version for the paper (drawn at its printed width, 2.8 in): no colour bar, because every count is printed
# next to its sensor; the shading repeats the count.
fig = plt.figure(figsize=(2.8, 2.3))
ax = fig.add_axes((0.02, 0.0, 0.96, 1.0), projection="polar")
ax.set_theta_zero_location("N"); ax.set_theta_direction(1)
ax.set_ylim(0, 1.19); ax.set_yticks([]); ax.set_xticks([]); ax.grid(False); ax.spines["polar"].set_visible(False)
ax.add_patch(plt.Circle((0, 0), 0.6, transform=ax.transData._b, fc="#f1f0ec", ec=INK2, lw=0.8, zorder=0))
for k in range(1, 25):
    th = np.deg2rad(ANG[k] - 180)
    f = freq[k] / n
    ax.scatter(th, 0.93, s=135, c=[cmap(0.08 + 0.92 * f)], edgecolors=INK2, linewidths=0.6, zorder=3)
    ax.text(th, 0.93, str(k), ha="center", va="center", fontsize=6.5, color="white" if f > 0.6 else INK, zorder=4)
    if freq[k]:
        ax.text(th, 1.105, f"{freq[k]}", ha="center", va="center", fontsize=6.5, color=INK, fontweight="bold")
ax.annotate("", xy=(0, 0.34), xytext=(0, 0.02), arrowprops=dict(arrowstyle="-|>", color=INK2, lw=0.9))
ax.text(0, 0.45, "front", ha="center", va="center", fontsize=7, color=INK2)
ax.text(np.pi, 0.22, "robot", ha="center", va="center", fontsize=7, color=INK2)
fig.savefig(FIG / "fig1_sensor_ring_compact.png", bbox_inches="tight", pad_inches=0.02); plt.close(fig)
print("saved fig1_sensor_ring_compact.png")

# ------------------------------------------------------------- Fig. 2 feature-count curves
R = pd.read_csv(RES / "summary_curve.csv")
fig, axes = plt.subplots(2, 1, figsize=(W, 3.9), sharex=True)
for ax, prot, title in zip(axes, ("random", "blocked"), ("(a) Stratified random splits (10 seeds)",
                                                          "(b) Blocked contiguous folds (5 folds, 50-row gap)")):
    sub = R[R.protocol == prot]
    full = sub[sub.ranking == "all"].iloc[0]
    ax.axhspan(full.mf1_mean - full.mf1_std, full.mf1_mean + full.mf1_std, color=GREY, alpha=0.18, lw=0)
    ax.axhline(full.mf1_mean, color=GREY, lw=1.1, ls=":", label="all 24 sensors")
    for rk, col, mk, ls, lab in (("impurity", C1, "o", "-", "impurity ranking"),
                                 ("permutation", C2, "s", "--", "permutation ranking")):
        d = sub[sub.ranking == rk].sort_values("k")
        ax.errorbar(d.k, d.mf1_mean, yerr=d.mf1_std, color=col, marker=mk, ms=4, ls=ls, capsize=2, lw=1.2,
                    elinewidth=0.8, label=lab)
    r10 = sub[sub.ranking == "random10"].iloc[0]
    ax.errorbar([10.35], [r10.mf1_mean], yerr=[r10.mf1_std], color=C3, marker="^", ms=5, ls="none", capsize=2,
                elinewidth=0.8, label="random 10 sensors")
    ax.annotate("random 10", (10.35, r10.mf1_mean), xytext=(12.2, r10.mf1_mean), fontsize=6.5, color=INK2, va="center")
    ax.set_ylim(0.78, 1.003); ax.set_title(title, fontsize=7.5, loc="left", color=INK)
    ax.set_ylabel("macro-F1")
axes[1].set_xlabel("number of sensors k"); axes[1].set_xticks([2, 4, 6, 8, 10, 12, 16, 20, 24])
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=2, fontsize=6.8, bbox_to_anchor=(0.55, -0.045))
fig.tight_layout(rect=(0, 0.06, 1, 1))
save(fig, "fig2_feature_count.png")

# Same curves as two separate single-column images (paper Fig. 1(a) and 1(b)), each with its own legend
for prot, title, name in (("random", "(a) Stratified random splits (10 seeds)", "fig2a_feature_count_random.png"),
                          ("blocked", "(b) Blocked contiguous folds (5 folds, 50-row gap)",
                           "fig2b_feature_count_blocked.png")):
    fig, ax = plt.subplots(figsize=(W, 2.05))
    sub = R[R.protocol == prot]
    full = sub[sub.ranking == "all"].iloc[0]
    ax.axhspan(full.mf1_mean - full.mf1_std, full.mf1_mean + full.mf1_std, color=GREY, alpha=0.18, lw=0)
    ax.axhline(full.mf1_mean, color=GREY, lw=1.1, ls=":", label="all 24 sensors")
    for rk, col, mk, ls, lab in (("impurity", C1, "o", "-", "impurity ranking"),
                                 ("permutation", C2, "s", "--", "permutation ranking")):
        d = sub[sub.ranking == rk].sort_values("k")
        ax.errorbar(d.k, d.mf1_mean, yerr=d.mf1_std, color=col, marker=mk, ms=4, ls=ls, capsize=2, lw=1.2,
                    elinewidth=0.8, label=lab)
    r10 = sub[sub.ranking == "random10"].iloc[0]
    ax.errorbar([10.35], [r10.mf1_mean], yerr=[r10.mf1_std], color=C3, marker="^", ms=5, ls="none", capsize=2,
                elinewidth=0.8, label="random 10 sensors")
    ax.set_ylim(0.78, 1.003); ax.set_xlim(1, 25); ax.set_title(title, fontsize=7.5, loc="left", color=INK)
    ax.set_ylabel("macro-F1"); ax.set_xlabel("number of sensors k")
    ax.set_xticks([2, 4, 6, 8, 10, 12, 16, 20, 24])
    ax.legend(loc="lower right", fontsize=6.3, handlelength=2.2, borderaxespad=0.3, labelspacing=0.3)
    fig.tight_layout()
    save(fig, name)

# ------------------------------------------------------------- Fig. 3 fault tests
F = pd.read_csv(RES / "fault_tests.csv")
fig, axes = plt.subplots(2, 1, figsize=(W, 3.7))
o = F[F.fault == "single_outage"].pivot_table(index="level", columns="model", values="acc")
ax = axes[0]
x = o.index.values
ax.plot(x, o["all24"] * 100, color=C1, marker="o", ms=3.5, ls="-", lw=1.0, label="24-sensor model")
ax.plot(x, o["top10"] * 100, color=C2, marker="s", ms=3.5, ls="--", lw=1.0, label="top-10 model")
for k, dx, ha in ((15, 0.7, "left"), (19, -0.7, "right"), (20, 0.7, "left")):
    ax.text(k + dx, o.loc[k, "top10"] * 100, f"US{k}", fontsize=6.5, color=INK2, ha=ha, va="center")
ax.set_xticks([1, 4, 8, 12, 16, 20, 24]); ax.set_xlabel("failed sensor (reads missing)")
ax.set_ylabel("accuracy (%)"); ax.set_title("(a) Single-sensor outage", fontsize=7.5, loc="left")
ax.legend(fontsize=6.8, loc="lower left")
d = F[F.fault == "dropout"].groupby(["level", "model"]).acc.agg(["mean", "std"]).reset_index()
ax = axes[1]
for mdl, col, mk, ls, lab in (("all24", C1, "o", "-", "24-sensor model"), ("top10", C2, "s", "--", "top-10 model")):
    s = d[d.model == mdl]
    ax.errorbar(s.level * 100, s["mean"] * 100, yerr=s["std"] * 100, color=col, marker=mk, ms=4, ls=ls, capsize=2,
                elinewidth=0.8, label=lab)
ax.set_xlabel("readings dropped at random (%)"); ax.set_ylabel("accuracy (%)")
ax.set_title("(b) Independent random dropout (10 repetitions)", fontsize=7.5, loc="left")
ax.legend(fontsize=6.8, loc="lower left")
fig.tight_layout(h_pad=1.2)
save(fig, "fig3_faults.png")

# Same fault panels as two separate single-column images (paper Fig. 3(a) and 3(b))
fig, ax = plt.subplots(figsize=(W, 1.85))
ax.plot(x, o["all24"] * 100, color=C1, marker="o", ms=3.5, ls="-", lw=1.0, label="24-sensor model")
ax.plot(x, o["top10"] * 100, color=C2, marker="s", ms=3.5, ls="--", lw=1.0, label="top-10 model")
for k, dx, ha in ((15, 0.7, "left"), (19, -0.7, "right"), (20, 0.7, "left")):
    ax.text(k + dx, o.loc[k, "top10"] * 100, f"US{k}", fontsize=6.5, color=INK2, ha=ha, va="center")
ax.set_xticks([1, 4, 8, 12, 16, 20, 24]); ax.set_xlabel("failed sensor (reads missing)")
ax.set_ylabel("accuracy (%)"); ax.set_title("(a) Single-sensor outage", fontsize=7.5, loc="left")
ax.legend(fontsize=6.8, loc="lower left")
ax.set_ylim(83, 100.5); ax.set_yticks([85, 90, 95, 100])
fig.tight_layout(); save(fig, "fig3a_single_outage.png")

fig, ax = plt.subplots(figsize=(W, 1.85))
for mdl, col, mk, ls, lab in (("all24", C1, "o", "-", "24-sensor model"), ("top10", C2, "s", "--", "top-10 model")):
    s = d[d.model == mdl]
    ax.errorbar(s.level * 100, s["mean"] * 100, yerr=s["std"] * 100, color=col, marker=mk, ms=4, ls=ls, capsize=2,
                elinewidth=0.8, label=lab)
ax.set_xlabel("readings dropped at random (%)"); ax.set_ylabel("accuracy (%)")
ax.set_title("(b) Independent random dropout (10 repetitions)", fontsize=7.5, loc="left")
ax.legend(fontsize=6.8, loc="lower left")
ax.set_ylim(83, 100.5); ax.set_yticks([85, 90, 95, 100])
fig.tight_layout(); save(fig, "fig3b_random_dropout.png")
print("freq", freq)
